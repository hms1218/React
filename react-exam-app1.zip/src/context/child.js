import { GrandChild } from "./gc"

export const Child = () => {
    return <GrandChild />
}
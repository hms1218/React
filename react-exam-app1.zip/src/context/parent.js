import { Child } from "./child"

export const Parent = () => {
    return <Child />
}